# Roda Putar PAI Kelas X SMK

Game edukasi interaktif Pendidikan Agama Islam tentang akhlak mazmumah:
- Berfoya-foya
- Riya
- Sum'ah

## Menjalankan secara lokal
Buka `index.html` di browser modern.

## Hosting dengan GitHub Pages
1. Buat repository baru di GitHub.
2. Unggah `index.html` dan `README.md` ke root repository.
3. Buka **Settings → Pages**.
4. Pada **Build and deployment**, pilih **Deploy from a branch**.
5. Pilih branch `main` dan folder `/(root)`, lalu klik **Save**.
6. Tunggu proses deployment selesai. URL website akan ditampilkan di halaman Pages.

Game ini menggunakan HTML, CSS, dan JavaScript di sisi browser; tidak membutuhkan backend, database, atau build step.
